"""
Author: Tomasz Hachaj, 2020
Department of Signal Processing and Pattern Recognition
Institute of Computer Science in Pedagogical University of Krakow, Poland
https://sppr.up.krakow.pl/hachaj/

Data source:
https://credo.nkg-mn.com/hits.html
"""

from prepare_img import process_dataset, process_image
from tensorflow_utils import enable_tensorflow, create_model_VGG16, create_model_NASNetLarge, \
    create_model_Xception, create_model_DenseNet201, create_model_MobileNetV2, create_dense_nn
from generate_features import generate_features
from transferlearning import transfer_learning
from Predictions import make_predictions
from ConfusionMatrix import calculate_confusion_matrix
from keras.layers import GlobalAveragePooling2D
from keras.models import Model
from keras.preprocessing import image
import numpy as np
from keras.applications.nasnet import preprocess_input
import cv2
import time

#Configurations
path_to_data = 'png\\'

my_model_name = 'VGG16'
#output_features_dir = 'Features/'
output_features_file = 'my_Features.txt'
output_processed_file = 'my_processed_files.txt'
output_results_file = 'my_results.txt'

hidden_layer_neurons_count = 128
output_layer_neurons_count = 4

print("******************************************")
print("Starting Tensorflow")
print("******************************************")
physical_devices = enable_tensorflow()

print("******************************************")
print("Reading embedding model")
print("******************************************")

my_model = None

if my_model_name == 'VGG16':
    my_model = create_model_VGG16()

x = my_model.output
x = GlobalAveragePooling2D()(x)

model_emb = Model(inputs=my_model.input, outputs=x)

print("******************************************")
print("Reading classifier")
print("******************************************")

features_shape = 512

import glob
import os
list_of_files = glob.glob('*.hdf5') # * means all if need specific format then *.csv
latest_file = max(list_of_files, key=os.path.getctime)
import numpy as np


input_layer_neurons_count = features_shape
model = create_dense_nn(input_layer_neurons_count, hidden_layer_neurons_count, output_layer_neurons_count)
model.load_weights(latest_file)

#List directory for all png
from os import listdir
from os.path import isfile, join
onlyfiles = [f for f in listdir(path_to_data) if isfile(join(path_to_data, f))]

print("******************************************")
print("Classification")
start = time.time()
print("******************************************")
for my_id in range(len(onlyfiles)):
    if my_id % 100 == 0:
        end = time.time()
        print(str(my_id) + " of " + str(len(onlyfiles)) + " elapsed time: " + str(end - start))

    file_name = onlyfiles[my_id]
    #Process image
    my_processed_image = process_image(path_to_data + file_name)
    x = cv2.merge([my_processed_image,my_processed_image,my_processed_image])

    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    #Make embeddings
    features = model_emb.predict(x)

    #Save embeddings
    file_object = open(output_features_file, 'a')
    features = features[0]
    for b in range(features.shape[0]):
        if b > 0:
            file_object.write(",")
        file_object.write(str(features[b]))
    file_object.write('\n')
    file_object.close()
    #Save file name
    file_object = open(output_processed_file, 'a')
    file_object.write(file_name)
    file_object.write('\n')
    file_object.close()

    #Make prediction
    my_x = np.copy(features)
    my_x = my_x.reshape(1, my_x.shape[0])
    my_prediction = model.predict(my_x)
    #print(my_prediction)

    file_object = open(output_results_file, 'a')
    file_object.write(file_name + ",")

    #Save predictions to file
    my_prediction = my_prediction[0]
    for b in range(my_prediction.shape[0]):
        if b > 0:
            file_object.write(",")
        file_object.write(str(my_prediction[b]))

    #Classification
    max_id = my_prediction.argmax()
    file_object.write(","+str(max_id))

    file_object.write(",")
    #Thresholds
    if my_prediction[max_id] > 0.5:
        file_object.write(str(max_id))
    else:
        file_object.write("NA")
    file_object.write(",")
    if my_prediction[max_id] > 0.75:
        file_object.write(str(max_id))
    else:
        file_object.write("NA")
    file_object.write(",")
    if my_prediction[max_id] > 0.9:
        file_object.write(str(max_id))
    else:
        file_object.write("NA")

    file_object.write('\n')
    file_object.close()

end = time.time()
print(" elapsed time: " + str(end - start))